---
name: popup-tent
description: Scaffolds a 4th Layer Engineering workflow environment into a repository. Installs hooks, run tracking infrastructure, subagent guide, context optimization docs, and a CLAUDE.md workflow section. Use when setting up a new repo for agent-driven development, or when adding structured run tracking and multi-agent workflow support to an existing project.
---

# Pop-Up Tent — 4th Layer Engineering Workflow Scaffold

This skill installs the 4th Layer Engineering workflow infrastructure into the current
repository. It takes ~10 minutes and leaves you with a complete agent operating environment:
run tracking, subagent protocol, hooks, templates, and a CLAUDE.md workflow section.

---

## Prerequisites

Before proceeding, confirm:
- [ ] You are in the root directory of the target repository
- [ ] Git is initialized (`git init` if not)
- [ ] Python 3 is available (for hooks — they use stdlib only)
- [ ] `~/bin/agent` is set up if you plan to use Cursor as a subagent (see SETUP.md)

**Skill package location:**
This SKILL.md and all accompanying files are in `CLAUDE-SKILLS/popup-tent/` at the
Code Projects root. All `files/` paths below are relative to that directory.

---

## What Gets Installed

| Artifact | Destination in Target Repo | Purpose |
|----------|----------------------------|---------|
| 5 hook scripts | `.claude/hooks/` | Enforce agent type, inject voice + protocol, remind TASK_LOG |
| Hook settings template | `.claude/settings-hooks-template.json` | Hooks wiring to merge into settings.local.json |
| `init-run.sh` | `runs/CLAUDE-RUNS/` | Initialize new run directories with timestamps |
| Blank `ARCHIVE.md` | `runs/CLAUDE-RUNS/` | Log of completed runs |
| Run templates (4 files) | `docs/coding_agents/claude_run_templates/` | TASK_LOG, SPEC, FINDINGS, README |
| `SUBAGENT_GUIDE.md` | `docs/coding_agents/` | When/how to spawn subagents |
| `MEMORY_OPTIMIZATION.md` | `docs/coding_agents/` | Context loading strategies |
| `docstring_validation_template.md` | `docs/templates/` | Run completion validation template |
| `skills/README.md` | `skills/` | Scaffold for future domain skills |
| `snippets/CLAUDE_MD_WORKFLOW.md` | `snippets/` (in target repo) | Workflow section to paste into CLAUDE.md |

---

## Installation

Work through these steps in order. Do not skip steps.

---

### Step 1: Create directories

Create all required directories in the target repo:

```bash
mkdir -p .claude/hooks
mkdir -p runs/CLAUDE-RUNS
mkdir -p docs/coding_agents/claude_run_templates/TASK_LOG
mkdir -p docs/coding_agents/claude_run_templates/SPEC
mkdir -p docs/coding_agents/claude_run_templates/FINDINGS
mkdir -p docs/templates
mkdir -p skills
mkdir -p snippets
```

---

### Step 2: Copy hook scripts

Read each file from the skill package and write it to the target repo:

| Source (in skill package) | Destination (in target repo) |
|---------------------------|------------------------------|
| `files/.claude/hooks/force-general-purpose-agent.py` | `.claude/hooks/force-general-purpose-agent.py` |
| `files/.claude/hooks/subagent-context.py` | `.claude/hooks/subagent-context.py` |
| `files/.claude/hooks/subagent-directory-protocol.py` | `.claude/hooks/subagent-directory-protocol.py` |
| `files/.claude/hooks/plan-mode-reminder.py` | `.claude/hooks/plan-mode-reminder.py` |
| `files/.claude/hooks/task-log-reminder.py` | `.claude/hooks/task-log-reminder.py` |

---

### Step 3: Copy settings template

Read `files/.claude/settings-hooks-template.json` from the skill package and write it
to `.claude/settings-hooks-template.json` in the target repo.

This contains only the `"hooks"` section. The user will merge it into their
`settings.local.json` (Step 10).

---

### Step 4: Copy run infrastructure

| Source | Destination |
|--------|-------------|
| `files/runs/.gitkeep` | `runs/.gitkeep` (empty file) |
| `files/runs/CLAUDE-RUNS/.gitkeep` | `runs/CLAUDE-RUNS/.gitkeep` (empty file) |
| `files/runs/CLAUDE-RUNS/init-run.sh` | `runs/CLAUDE-RUNS/init-run.sh` |
| `files/runs/CLAUDE-RUNS/ARCHIVE.md` | `runs/CLAUDE-RUNS/ARCHIVE.md` |

---

### Step 5: Copy run templates

| Source | Destination |
|--------|-------------|
| `files/docs/coding_agents/claude_run_templates/README.md` | `docs/coding_agents/claude_run_templates/README.md` |
| `files/docs/coding_agents/claude_run_templates/TASK_LOG/TASK_LOG.md` | `docs/coding_agents/claude_run_templates/TASK_LOG/TASK_LOG.md` |
| `files/docs/coding_agents/claude_run_templates/SPEC/SPEC_v1.md` | `docs/coding_agents/claude_run_templates/SPEC/SPEC_v1.md` |
| `files/docs/coding_agents/claude_run_templates/FINDINGS/FINDINGS.md` | `docs/coding_agents/claude_run_templates/FINDINGS/FINDINGS.md` |

---

### Step 6: Copy documentation

| Source | Destination |
|--------|-------------|
| `files/docs/coding_agents/SUBAGENT_GUIDE.md` | `docs/coding_agents/SUBAGENT_GUIDE.md` |
| `files/docs/coding_agents/MEMORY_OPTIMIZATION.md` | `docs/coding_agents/MEMORY_OPTIMIZATION.md` |
| `files/docs/templates/docstring_validation_template.md` | `docs/templates/docstring_validation_template.md` |

---

### Step 7: Copy skills scaffold

| Source | Destination |
|--------|-------------|
| `files/skills/README.md` | `skills/README.md` |

---

### Step 8: Copy snippets

| Source | Destination |
|--------|-------------|
| `files/../snippets/CLAUDE_MD_WORKFLOW.md` | `snippets/CLAUDE_MD_WORKFLOW.md` |

(The snippets directory is at `CLAUDE-SKILLS/popup-tent/snippets/`, not inside `files/`.)

---

### Step 9: Update .gitignore

Append the following to `.gitignore` (create the file if it doesn't exist):

```
# Claude agent run directories (local only — contents never committed)
runs/
!runs/.gitkeep

# Log files
*.log
```

Do NOT replace an existing `.gitignore` — append only.

---

### Step 10: Make init-run.sh executable and force-add tracked files

```bash
chmod +x runs/CLAUDE-RUNS/init-run.sh

git add -f runs/.gitkeep
git add -f runs/CLAUDE-RUNS/.gitkeep
git add -f runs/CLAUDE-RUNS/ARCHIVE.md
git add -f runs/CLAUDE-RUNS/init-run.sh
```

---

### Step 11: Test run infrastructure

```bash
cd runs/CLAUDE-RUNS && ./init-run.sh test-tent
```

Expected output: `✅ Created: runs/CLAUDE-RUNS/RUN-YYYYMMDD-HHMM-test-tent/` with
both `TASK_LOG.md` and `SPEC_v1.md` present and timestamps substituted (not `{{RUN_ID}}`
literals).

If template variables aren't substituted, check that `docs/coding_agents/claude_run_templates/`
is populated correctly from Step 5.

---

## Customization Pass

The infrastructure is now installed. This pass fills in the project-specific
`[TODO]` markers so the docs accurately reflect *this* project.

Work through each file. For each `[TODO]`, decide whether to fill it in now
(if you know the answer) or mark it for later (add `[TODO: revisit]`).

---

### Customize: MEMORY_OPTIMIZATION.md

Open `docs/coding_agents/MEMORY_OPTIMIZATION.md`.

**Fill in these sections:**

1. **Progressive Disclosure table** (top of file) — replace `[your quick reference doc]`,
   `[your troubleshooting doc]`, etc. with your project's actual documentation file names.

2. **Tier 1 Constants block** — add your project's:
   - Service/port mappings
   - Import path pattern (e.g., `from mypackage.` not `from src.mypackage.`)
   - Core architectural rules (e.g., "Config DB for metadata only, never for client data")

3. **Tier 2 table** — fill in your actual doc names and approximate sizes.

4. **Decision trees** — replace `[quick reference doc]`, `[troubleshooting doc]`, etc.
   with your actual file names.

5. **Tip 2: Cache Constants** — list your project's key constants (ports, import patterns,
   critical rules) so agents know what to cache.

6. **Update the "Last Updated" line** at the bottom.

If you don't know the answers yet, that's fine — leave the `[TODO]` markers and fill
them in during your first few runs on the project.

---

### Customize: SUBAGENT_GUIDE.md

Open `docs/coding_agents/SUBAGENT_GUIDE.md`.

**Fill in this section:**

1. **§3 Example Prompt** — there is a `[TODO]` comment at the bottom of §3. Replace the
   generic "users table" example with one relevant to your project (a real table, a real
   investigation scenario, or a real verification task you'd actually run).

2. **Update the "Last Updated" line** at the bottom.

---

### Customize: CLAUDE.md workflow section

The file `snippets/CLAUDE_MD_WORKFLOW.md` contains the full workflow section
ready to paste into CLAUDE.md.

Ask the user: **"Do you have an existing CLAUDE.md, or should I create a new one?"**

**If creating new:** Copy `snippets/CLAUDE_MD_WORKFLOW.md` to `CLAUDE.md`. Then add
a project-specific header section above the workflow section covering:
- Project name and purpose
- Documentation map (what docs exist and when to use them)
- Key architectural concepts
- Quick reference (ports, commands, critical file locations)
- Common pitfalls

**If merging with existing:** Paste the workflow sections from
`snippets/CLAUDE_MD_WORKFLOW.md` into the appropriate place in the existing CLAUDE.md.
At minimum, ensure these sections are present:
- Core Task Execution Protocol
- Agent Task Tracking Protocol
- Active Tasks table
- Subagent Usage + Codex + Cursor sections
- Background Process Guidelines
- Timestamp reminder

After merging, fill in all `[TODO: project-specific]` markers in CLAUDE.md.

---

### Finalize: Configure settings.local.json

Merge `.claude/settings-hooks-template.json` into `.claude/settings.local.json`:

- If no `settings.local.json` exists: rename the template to `settings.local.json`
- If it exists: merge the `"hooks"` key into the existing file without overwriting
  other keys (`permissions`, `enabledMcpjsonServers`, `additionalDirectories`, etc.)

After merging, delete `.claude/settings-hooks-template.json`.

---

## Completion Checklist

Verify everything before starting work:

- [ ] `chmod +x runs/CLAUDE-RUNS/init-run.sh` done
- [ ] `./init-run.sh test-tent` succeeded with substituted timestamps
- [ ] `.claude/settings.local.json` has `"hooks"` key with 5 entries
- [ ] `MEMORY_OPTIMIZATION.md` — Tier 1 constants filled in (or `[TODO]` markers left intentionally)
- [ ] `SUBAGENT_GUIDE.md` — project example added (or `[TODO]` left intentionally)
- [ ] CLAUDE.md has the workflow section (Active Tasks table, run protocol, subagent section)
- [ ] `.gitignore` has `runs/` + `!runs/.gitkeep` appended
- [ ] `runs/.gitkeep`, `runs/CLAUDE-RUNS/.gitkeep`, `ARCHIVE.md`, `init-run.sh` force-added to git

---

## What's NOT installed (by design)

The following were intentionally excluded. Add them yourself if needed:

| What | Why excluded |
|------|-------------|
| `post-edit-lint.py` hook | Language/toolchain specific (Python/poetry). Add your own linting hook. |
| Project-specific permissions in settings.local.json | You know your project's allowed bash commands. |
| `AGENTS.md` | Project-specific repository guidelines. Write your own. |
| `EXAMPLES.md`, `VISUAL_DIAGRAMS.md` | Project-specific code examples. Write your own. |
| `GEMINI-RUNS/` | Add `runs/GEMINI-RUNS/` yourself if you use Gemini agents. |
| MCP query templates | Specific to your database tooling. |
